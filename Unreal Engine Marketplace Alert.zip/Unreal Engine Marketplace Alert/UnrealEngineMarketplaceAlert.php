<?php
/*
Plugin Name: Unreal Engine Marketplace Alert
Description: Checks for new items in the Unreal Engine Marketplace and sends an email alert to a custom email address.
Version: 1.0
Author: Nxvermore
*/

function check_marketplace() {
    // Use cURL to retrieve the page source of the marketplace page
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://www.unrealengine.com/marketplace/en-US/store");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $marketplace_html = curl_exec($ch);
    curl_close($ch);

    // Use regular expressions to check for new items on the page
    preg_match_all('/class="title"\>(.+?)\</', $marketplace_html, $matches);
    $new_items = $matches[1];

    // If there are new items, send an email alert
    if (!empty($new_items)) {
        $to = "custom@email.com";
        $subject = "New items on the Unreal Engine Marketplace";
        $message = "There are new items on the Unreal Engine Marketplace: \n\n";
        $message .= implode("\n", $new_items);
        $headers = "From: marketplace-alert@yourdomain.com";
        mail($to, $subject, $message, $headers);
    }
}

// Schedule the check_marketplace() function to run every day
if (!wp_next_scheduled('check_marketplace_event')) {
    wp_schedule_event(time(), 'daily', 'check_marketplace_event');
}
add_action('check_marketplace_event', 'check_marketplace');